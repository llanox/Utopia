Latest XMLPULL V1 API jars can be downloaded from http://www.xmlpull.org/
