package com.raditha.articles;

import javax.swing.*;

/**
 * Copyright Raditha Dissanayake 2005
 * http://www.raditha.com/
 * @author Raditha Dissanyake
 * @version 1.0
 */


public class JSHelloWorld extends JApplet {
    JTextArea txt = new JTextArea(100,100);
    public JSHelloWorld() {
        txt.setText("Hello World");
        getContentPane().add(txt);
    }
}
